﻿namespace back.Core.Domain.Records
{
    public record class LoginData(string email, string password);
}
