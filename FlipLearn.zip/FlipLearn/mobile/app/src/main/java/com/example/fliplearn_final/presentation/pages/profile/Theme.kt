package com.example.fliplearn_final.presentation.pages.profile

enum class Theme(val displayName: String) {
    Light("Світла"),
    Dark("Темна"),

}